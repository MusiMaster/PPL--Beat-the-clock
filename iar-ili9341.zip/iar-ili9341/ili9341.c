#include "ili9341.h"
#include "ascii.h"

//####################################################################################################################################################################################
//                                                                      ILI9341_SPI_init()
//
// Initialisiert SPI-UCB0 des Mikrocontrollers MSP430G2553. Beachte der MSP430G2553 besitzt zus�tzlich den UCA0 f�r SPI.
//
void ILI9341_SPI_init(void)
{
  P1SEL  |=  ILI9341_MOSI + ILI9341_SCK;                                         // Spezial Funktion SCK, MOSI und MISO ...
  P1SEL2 |=  ILI9341_MOSI + ILI9341_SCK;                                         // (Falls P1SEL2 unterst�tzt).-
  
  P1DIR  |=  ILI9341_RST + ILI9341_DC + ILI9341_CS;                              // RST-, DC- und !CS-Leitung  ...
  P1OUT  &=~ ILI9341_RST + ILI9341_DC + ILI9341_CS;                              // .-
  
  UCB0CTL1 |= UCSWRST;					                         // Reset  
  UCB0CTL0 |=  UCMST + UCSYNC + UCCKPH + UCMSB;		                         // 3-pin, 8-bit SPI master
  UCB0CTL1 |=  UCSSEL_2;					                 // SMCLK
  UCB0CTL1 &=~ UCSWRST;					                         // USCI released for operation
  //UCA0MCTL = 0;                                                                // No modulation
  
  __delay_cycles(DELAY_100ms);                                                   // Warte 100ms
  while (!(IFG2 & UCB0TXIFG));                                                   // Warte bist �bermittelt
  UCB0TXBUF = 0x00;                                                              // Dummy Senden 
}

//####################################################################################################################################################################################
//                                                                     ILI9341_SPI_transmit()
//
// Senden und Empfangen �ber SPI-UCB0.
//
//                               Variablen
// @ data     : Unsigned 8-Bit-Datensatz der �ber UCB0 via SPI gesendet werden soll
//
// @ return   : Unsigned 8-Bit-Datensatz der �ber UCB0 via SPI empfangen wird
//
unsigned char ILI9341_SPI_transmit(unsigned char data)
{   
  UCB0TXBUF = data;                                                              // Sende Datensatz
  while(UCB0STAT & UCBUSY);                                                      // Warte bist �bermittelt
  return UCB0RXBUF;                                                              // Gebe empfangenen Datensatz zur�ck    
} 

//####################################################################################################################################################################################
//                                                                     ILI9341_SendComand()
//
// Sende dem ILI9341 einen Befehl �ber SPI-UCB0.
//
//                               Variablen
// @ cmd      : Unsigned 8-Bit-Befehl der �ber UCB0 via SPI gesendet werden soll
//
void ILI9341_SendComand(uint8_t cmd)
{
  P1OUT &=~ ILI9341_DC;			                                         // Signalisiere das ein Befehl gesendet wird. ...
  P1OUT &=~ ILI9341_CS;				                                 // Starte Frame in dem ich !CS auf Low Ziehe. Sende ...
  
  ILI9341_SPI_transmit(cmd);                                                   // sende Befehl ...
  
  P1OUT |= ILI9341_CS;				                                 // Beende den Frame in dem ich !CS wieder auf High setze.-
}

//####################################################################################################################################################################################
//                                                                     ILI9341_SendData8()
//
// Sende dem ILI9341 einen 8-Bit-Datensatz �ber SPI-UCB0.
//
//                               Variablen
// @ data     : Unsigned 8-Bit-Daten der �ber UCB0 via SPI gesendet werden soll
//
void ILI9341_SendData8(uint8_t data)
{
  P1OUT |= ILI9341_DC;			                                         // Signalisiere das ein Daten gesendet werden. ...
  P1OUT &=~ ILI9341_CS;				                                 // Starte Frame in dem ich !CS auf Low Ziehe. Sende ...
  
  ILI9341_SPI_transmit(data);                                                    // sende Daten ...
  
  P1OUT |= ILI9341_CS;				                                 // Beende den Frame in dem ich !CS wieder auf High setze.-
}

//####################################################################################################################################################################################
//                                                                     ILI9341_SendData16()
//
// Sende dem ILI9341 einen 16-Bit-Datensatz �ber SPI-UCB0.
//
//                               Variablen
// @ data     : Unsigned 16-Bit-Daten der �ber UCB0 via SPI gesendet werden soll
//
void ILI9341_SendData16(uint16_t data)
{ 
  P1OUT |= ILI9341_DC;                                                           // Signalisiere das ein Daten gesendet werden. ...
  P1OUT &=~ ILI9341_CS;	                                                         // Starte Frame in dem ich !CS auf Low Ziehe. Sende ...
  
  ILI9341_SPI_transmit(data >> 8);                                               // Sende Low und High byte �ber SPI ...
  ILI9341_SPI_transmit(data & 0xff);                                             // .-
  
  P1OUT |= ILI9341_CS;				                                 // Beende den Frame in dem ich !CS wieder auf High setze.-	
}

//####################################################################################################################################################################################
//                                                                   ILI9341_SendPackage()
//
// Sende dem ILI9341 eine Packet aud Daten (Array).
//
//                               Variablen
// @ data     : Unsigned 16-Bit-Daten-Array der �ber UCB0 via SPI gesendet werden soll
// @ data     : Anzahl der Daten des Arrays die gesendet werden sollen
//
void ILI9341_SendPackage(uint16_t *data, uint8_t howmany)
{
  P1OUT |= ILI9341_DC;                                                           // Signalisiere das ein Daten gesendet werden. ...
  P1OUT &=~ ILI9341_CS;	                                                         // Starte Frame in dem ich !CS auf Low Ziehe. Sende ...
  
  uint8_t count=0;                                                               // Z�hler
  for(count=0; count < howmany; count++)                                         // S�nder alle Daten aus Array
  {
    ILI9341_SPI_transmit(data[count]>>8);                                        // Sende Low und High byte �ber SPI ...
    ILI9341_SPI_transmit(data[count]&0xff);                                      // .-
  } // for
  
  P1OUT |= ILI9341_CS;				                                 // Beende den Frame in dem ich !CS wieder auf High setze.-
}

//####################################################################################################################################################################################
//                                                                       ILI9341_Init()
//
// Initialisiert das Display. Beachte SPI sollte schon vorher initialisiert sein. 
//
// F�r die LCD-Initialisierung: * Resete LCD
//                              * Sende Startsequenz zum LCD
//                              * Verlasse Standby und stelle Farbe ein
//                              * Stelle die Ausrichtung vom Display (portrait, landscape, ...)
// 
//
//                               Variablen
// @ color    : Farbauswahl siehe #defines in der ili9341.h
//
void ILI9341_Init(uint16_t color)
{
  uint8_t byte = 0, bit_num = 0, h_index = 0, w_index = 0;                       // Schleifen-Z�hler f�r Daten/Befehls-Arrays

  // 1. LCD Reset
  
  for(char i = 0; i < 3; i++)                                                    // Reset-Sequenz f�r das Display. Beachte i muss ungerade Zahl sein. ...
  {                                                                              // Ohne Sequenz funktioniert LCD nicht (schon getestet). ...
    P1OUT ^= ILI9341_RST;                                                        // RST-Pin Toggeln ...
    __delay_cycles(DELAY_1ms);                                                   // Warte 1ms.-
  } // for
  
  // 2. Schalte nun die Startsequenz f�r das Display an
  
  const uint8_t init_cmd[]={0xCB,0xCF,0xE8,0xEA,0xED,0xF7,0xC0,0xC1,0xC5,0xC7,   // Befehls-Array ...
                            0x36,0x3A,0xB1,0xB6,0xF2,0x26,0xE0,0xE1};            // .-
  
  const uint8_t init_data[]={0x39,0x2C,0x00,0x34,0x02,0x00,0xC1,0x30,0x85,0x00,  // Daten-Array ...
                             0x78,0x00,0x00,0x64,0x03,0x12,0x81,0x20,0x23,0x10,  // ...
                             0x3E,0x28,0x86,0x88,0x55,0x00,0x18,0x08,0x82,0x27,  // ...
                             0x00,0x01,0x0F,0x31,0x2B,0x0C,0x0E,0x08,0x4E,0xF1,  // ...
                             0x37,0x07,0x10,0x03,0x0E,0x09,0x00,0x00,0x0E,0x14,  // ...
                             0x03,0x11,0x07,0x31,0xC1,0x48,0x08,0x0F,0x0C,0x31,  // ...
                             0x36,0x0F};                                         // .-
  
  const uint8_t init_data_count[]={5,3,3,2,4,1,1,1,2,1,1,1,2,3,1,1,15,15};
  
  while(byte < sizeof(init_cmd))						 // F�r byte < 18 (= L�nge vom Array)
  {
    ILI9341_SendComand(init_cmd[byte++]);		                 // Schreibe-Befehl im Register	...
    while(h_index < init_data_count[bit_num])			                 // h_index f�r Gr��e von init_data Befels-Z�hler ...
    {										 // bit_num f�r init_data_count Z�hler ...
      ILI9341_SendData8(init_data[w_index++]);	                 // w_index f�r init_data Z�hler ...
      h_index++;                                                                 // ...
    } // while
    
    bit_num++;                                                                   // ...
    h_index = 0;                                                                 // ..-
  } // while
  
  // 3. Komme aus dem Standby (Sleep-Mode -> Siehe auch �8.2.12, ILI9341-Datenblatt, Seite 101)

  ILI9341_SendComand(ILI9341_SLPOUT);                                // Komme aus den Sleep-Out ...
  __delay_cycles(2 * DELAY_100ms);                                               // warte mindestens 120ms (sehe description Seite 101).-
  ILI9341_FillScreen(color);                                  // Bef�lle das ganze Display mit der gew�nschten Farbe
  ILI9341_SendComand(ILI9341_DISPON);                                // Mache Dsiplay an
  
  ILI9341_SendComand(ILI9341_RAMWR);                                 // Schreibe-Befehl im Memory Register
  ILI9341_SendComand(ILI9341_RAMWR);                                 // Schreibe-Befehl im Memory Register
  
  ILI9341_Orientation(LCD_ORIENTATION);                                          // Setze Orientations des Display (Portrait oder Landscape)
}

//####################################################################################################################################################################################
//                                                                   ILI9341_Orientation()
//
// Stellt die Ausrichtung vom Display (portrait, landscape, ...). Siehe dazu auch ili9341.h das #define LCD_ORIENTATION. Default ist 0�.
// Siehe auch �8.2.29, ILI9341-Datenblatt, Seite 127.
//
//                               Variablen
// @ deg      : Ausrichtung vom Display  <<LCD_ORIENTATION>> (siehe auch #defines in ili9341.h)
//
void ILI9341_Orientation (int deg)
{
  unsigned dat = 0;                                                              // Variable zum Beschreiben der Adresse MADCTL vom ILI9341

  switch(deg)                                                                    // Anhand der erw�nschen Ausrichtung, stelle MEM_X, MEM_Y, MEM_V, MEM_L und MEM_BGR. ...
  {                                                                              // Siehe auch Tabelle auf Seite 127. ...
    case 0:                                                                      // ...
    {                                                                            // ...
      dat = (1 << MEM_X) | (1 << MEM_BGR);                                       // ... 
      break;                                                                     // ...
    } // case                                                                    // ...
    //--------------------------------------------------------------------------
    case 90:                                                                     // ...
    {                                                                            // ...   
      dat = (0<<MEM_Y)  | (0<<MEM_X)  | (1<<MEM_V) | (0<<MEM_L)  | (1<<MEM_BGR); // ...   
      break;                                                                     // ...                                                                     
    } // case                                                                    // ...
    //--------------------------------------------------------------------------
    case 180:                                                                    // ...
    {
      dat = (1 << MEM_Y) | (1 << MEM_BGR);                                       // ...   
      break;                                                                     // ...                                                                     
    } // case                                                                    // ...
    //--------------------------------------------------------------------------
    case 270:                                                                    // ... 
    {                                                                            // ...   
      dat = (1 << MEM_Y) | (1<<MEM_X) | (1<<MEM_V) | (1 << MEM_BGR);             // ...
      break;                                                                     // ...                                                                     
    } // case                                                                    // ...
    //--------------------------------------------------------------------------
    default:                                                                     // ...                                                                     
    {                                                                            // ...
      dat = (1 << MEM_X) | (1 << MEM_BGR);                                       // ...   
    } // default                                                                 // .-
  } // switch   
    
  ILI9341_SendComand (ILI9341_MADCTL);                               // Siehe auch Flow-Chart, Seite 128. Sende Befehl zuerst, dann ...
  ILI9341_SendData8 (dat);                                             // den Datensatz.-
}



//####################################################################################################################################################################################
//                                                                   ILI9341_DisplayINV()
//
// Regelt das Inventieren der Farben des Displays.
//
//                               Variablen
// @ inv      : Variable f�rs Inventieren des Displays; TRUE f�r an - FALSE f�r aus
//
void ILI9341_DisplayINV(char inv) 
{
  if(inv == TRUE) ILI9341_SendComand (ILI9341_INVON);                            // Display-Farben inventieren
  else ILI9341_SendComand (ILI9341_INVOFF);                                      // Display-Farben NICHT inventieren
}

//####################################################################################################################################################################################
//                                                                   ILI9341_DisplayONorOFF()
//
// Regelt das ein- oder auschalten des Displays.
//
//                               Variablen
// @ ONorOFF  : Variable f�rs ein- oder auschalten des Displays; TRUE f�r an - FALSE f�r aus
//
void ILI9341_DisplayONorOFF(char ONorOFF) 
{
  if(ONorOFF == TRUE) ILI9341_SendComand (ILI9341_DISPON);                       // Display Anschalten
  else ILI9341_SendComand (ILI9341_DISPOFF);                                     // Display Ausschalten
}

//####################################################################################################################################################################################
//                                                                       ILI9341_SetX()
//
// Die Funktion sollte zusammen mit ILI9341_SetY() genutzt werden. Damit wird im RAM die Pixelposition der Y-Koordinate reserviert (siehe Datenblatt - Seite 110 und 111). Beachte Y 
// sollte auch eingestellt werden. Beachte der Datensatz wird noch nicht mit dem ILI9341_RAMWR-Befehl abgeschlossen.
//
//                               Variablen
// @ x        : X-Position aus kartesischen XY-Koordinatensystem
//
void ILI9341_SetX(uint16_t StartCol,uint16_t EndCol)
{
  ILI9341_SendComand(ILI9341_CASET);                                             // Befehl f�r die X-Koordinate, siehe Datenblatt - Seite 110 und 111
  ILI9341_SendData16(StartCol);                                                  // Startwert
  ILI9341_SendData16(EndCol);                                                    // Endwert (Beachte kein Abschlie�en durch ILI9341_RAMWR)
}

//####################################################################################################################################################################################
//                                                                       ILI9341_SetY()
//
// Die Funktion sollte zusammen mit ILI9341_SetX() genutzt werden. Damit wird im RAM die Pixelposition der X-Koordinate reserviert (siehe Datenblatt - Seite 112 und 112). Beachte X 
// sollte auch eingestellt werden. Beachte der Datensatz wird noch nicht mit dem ILI9341_RAMWR-Befehl abgeschlossen.
//
//                               Variablen
// @ y        : Y-Position aus kartesischen XY-Koordinatensystem
//
void ILI9341_SetY(uint16_t StartPage,uint16_t EndPage)
{
  ILI9341_SendComand(ILI9341_PASET);                                             // Befehl f�r die Y-Koordinate, siehe Datenblatt - Seite 112 und 113
  ILI9341_SendData16(StartPage);                                                 // Startwert
  ILI9341_SendData16(EndPage);                                                   // Endwert (Beachte kein Abschlie�en durch ILI9341_RAMWR)
}

//####################################################################################################################################################################################
//                                                                       ILI9341_SetXY()
//
// Stellt die X und Y-Koordinaten f�r das Pixel ein und schreibte es in der Memory (ILI9341_RAMWR). Beachte das Ergebnis ist nicht auf dem Display sichtbar, da noch die Farbe einge-
// stellt werden sollte.
//
//                               Variablen
// @ x        : X-Position aus kartesischen XY-Koordinatensystem
// @ y        : Y-Position aus kartesischen XY-Koordinatensystem
//
void ILI9341_SetXY(uint16_t x, uint16_t y)
{
  ILI9341_SetX(x, x);                                                            // Stelle X- und ...
  ILI9341_SetY(y, y);                                                            // Y-Koordinate ...
  ILI9341_SendComand(ILI9341_RAMWR);                                             // Schreibe es im Memory des ILI9341.-
}

//####################################################################################################################################################################################
//                                                                      ILI9341_SetPixel()
//
// Zeichnet dem Display einzelne Pixels ein.
//
//                               Variablen
// @ x        : X-Position aus kartesischen XY-Koordinatensystem
// @ y        : Y-Position aus kartesischen XY-Koordinatensystem
// @ color    : Farbe f�r das Pixels
//
void ILI9341_SetPixel(uint16_t poX, uint16_t poY,uint16_t color)
{
  ILI9341_SetXY(poX, poY);                                                       // W�hle Pixel aus XY-Koordinatensystem
  ILI9341_SendData16(color);                                                     // Sende erw�nschte Farbe
}

//####################################################################################################################################################################################
//                                                                      ILI9341_DrawPixel()
//
// Zeichnet dem Display einzelne Pixels ein (Funktion ist identisch mit ILI9341_SetPixel(), mache eine logische Trennung).
//
//                               Variablen
// @ x        : X-Position aus kartesischen XY-Koordinatensystem
// @ y        : Y-Position aus kartesischen XY-Koordinatensystem
// @ color    : Farbe f�r das Pixel
//
void ILI9341_DrawPixel(int16_t x, int16_t y, uint16_t color)
{ 
  ILI9341_SetXY(x, y);                                                           // W�hle Pixel aus XY-Koordinatensystem
  ILI9341_SendData16 (color);                                                    // Sende erw�nschte Farbe
}

//####################################################################################################################################################################################
//                                                                      ILI9341_DrawPixelXY()
//
// Zeichnet dem Display mehrere Pixels ein.
//
//                               Variablen
// @ x        : X-Position aus kartesischen XY-Koordinatensystem
// @ y        : Y-Position aus kartesischen XY-Koordinatensystem
// @ sx       : Breite f�r die X-Komponente einstellen
// @ sy       : Breite f�r die Y-Komponente einstellen
// @ color    : Farbe f�r das Pixel
//
void ILI9341_DrawPixelXY(int16_t x, int16_t y, uint8_t sx, uint8_t sy, uint16_t color)
{
  if(sx || sy) ILI9341_FillRectangle(x, x + sx, y, y + sy, color);               // Setze hiermit ganzen Bereich aus Pixel
  else 
  {
    ILI9341_SetX(x, x);                                                          // Setze einzelnt Y und ...
    ILI9341_SetY(y, y);                                                          // Y-Koordinate.-

    ILI9341_SendData16 (color);                                                  // Abschlie�end erw�nschte Farbe senden
  } // else
}

//####################################################################################################################################################################################
//                                                                      ILI9341_DrawChar()
//
// Zeichnet ein einzelnes Zeichen auf ds Display.
//
//                               Variablen
// @ ascii    : Nummer aus der ACII-Tabelle
// @ x        : X-Position auf das Display
// @ y        : Y-Position auf das Display
// @ size     : Breite und L�nge des Zeichens
// @ color    : Farbe f�r das Zeichen
//
void ILI9341_DrawChar(uint8_t ascii, uint16_t x, uint16_t y,uint16_t size, uint16_t color)
{
  if((ascii>=32)&&(ascii<=127)) ;  
  else
  {
    ascii = '?'-32;
  } // else
  
  for (int i =0; i<FONT_X; i++ ) 
  {
    uint8_t temp = simpleFont[ascii-0x20][i];
    for(uint8_t f=0;f<8;f++)
    {
      if((temp>>f)&0x01)
      {
        ILI9341_FillRectangle(x+i*size, y+f*size, size, size, color);
      } // if
    } // for/f
  } // for/i
}

//####################################################################################################################################################################################
//                                                                      ILI9341_DrawString()
//
// Zeichnet ein string (Zeichen-Array) auf ds Display.
//
//                               Variablen
// @ string   : String was auf das Display gezeichnet werden soll
// @ x        : X-Position auf das Display
// @ y        : Y-Position auf das Display
// @ size     : Breite und L�nge des Zeichens
// @ color    : Farbe f�r das Zeichen
//
void ILI9341_DrawString(char *string,uint16_t x, uint16_t y, uint16_t size,uint16_t color)
{
  while(*string)
  {
    ILI9341_DrawChar(*string, x, y, size, color);
    *string++;

    if(x < MAX_X)
    {
      x += FONT_SPACE*size;                                    
    } // if
  } // while
}

//####################################################################################################################################################################################
//                                                                      ILI9341_DrawHLine()
//
// Zeichnet einne horizontale Linie ein.
//
//                               Variablen
// @ x        : X-Position der Linie
// @ y        : Y-Position der Linie
// @ length   : L�nge der Linie
// @ color    : Farbe der Linie
//
void ILI9341_DrawHLine(uint16_t x, uint16_t y, uint16_t length,uint16_t color)
{
    ILI9341_SetX(x,x + length);
    ILI9341_SetY(y,y);
    ILI9341_SendComand(ILI9341_RAMWR);
    for(int i=0; i<length; i++) ILI9341_SendData16(color);
}

//####################################################################################################################################################################################
//                                                                      ILI9341_DrawVLine()
//
// Zeichnet einne vertikale Linie ein.
//
//                               Variablen
// @ x        : X-Position der Linie
// @ y        : Y-Position der Linie
// @ length   : L�nge der Linie
// @ color    : Farbe der Linie
//
void ILI9341_DrawVLine( uint16_t x, uint16_t y, uint16_t length,uint16_t color)
{
  ILI9341_SetX(x,x);
  ILI9341_SetY(y,y+length);
  ILI9341_SendComand(ILI9341_RAMWR);
  for(int i=0; i<length; i++) ILI9341_SendData16(color);
}

//####################################################################################################################################################################################
//                                                                      ILI9341_DrawLine()
//
// Zeichnet einne Linie ein.
//
//                               Variablen
// @ x0       : X-Startposition der Linie
// @ y0       : Y-Startposition der Linie
// @ x1       : X-Endposition der Linie
// @ y2       : Y-Endposition der Linie
// @ color    : Farbe der Linie
//
void ILI9341_DrawLine(uint16_t x0,uint16_t y0,uint16_t x1, uint16_t y1,uint16_t color)
{
  int x = x1-x0;
  int y = y1-y0;
  int dx = abs(x), sx = x0<x1 ? 1 : -1;
  int dy = -abs(y), sy = y0<y1 ? 1 : -1;
  int err = dx+dy, e2;                                                           // error value e_xy             
  
  for (;;)
  {                                                                              // loop                         
    ILI9341_SetPixel(x0,y0,color);
    e2 = 2*err;
    if (e2 >= dy) {                                                              // e_xy+e_x > 0                 
        if (x0 == x1) break;
        err += dy; x0 += sx;
    } // if
    if (e2 <= dx) {                                                              // e_xy+e_y < 0                 
        if (y0 == y1) break;
        err += dx; y0 += sy;
    } // if
  } // for
}

//####################################################################################################################################################################################
//                                                                      ILI9341_DrawRectangle()
//
// Zeichnet ein Rechteck auf das Display ein.
//
//                               Variablen
// @ x        : X-Position auf das Display
// @ y        : Y-Position auf das Display
// @ length   : L�nge des Rechtecks
// @ width    : Breite des Rechtecks
// @ color    : Farbe des Rechtecks
//
void ILI9341_DrawRectangle(uint16_t x, uint16_t y, uint16_t length, uint16_t width,uint16_t color)
{
  ILI9341_DrawHLine(x, y, length, color);
  ILI9341_DrawHLine(x, y+width, length, color);
  ILI9341_DrawVLine(x, y, width,color);
  ILI9341_DrawVLine(x + length, y, width,color);
}

//####################################################################################################################################################################################
//                                                                      ILI9341_DrawCircle()
//
// Zeichnet ein Kreis auf das Display ein.
//
//                               Variablen
// @ pox      : X-Position auf das Display
// @ poy      : Y-Position auf das Display
// @ r        : Radius des Kreises
// @ color    : Farbe des Kreises
//
void ILI9341_DrawCircle(int poX, int poY, int r,uint16_t color)
{
  int x = -r, y = 0, err = 2-2*r, e2;
  do {
      ILI9341_SetPixel(poX-x, poY+y,color);
      ILI9341_SetPixel(poX+x, poY+y,color);
      ILI9341_SetPixel(poX+x, poY-y,color);
      ILI9341_SetPixel(poX-x, poY-y,color);
      
      e2 = err;    
      if (e2 <= y) {
          err += ++y*2+1;
          if (-x == y && e2 <= x) e2 = 0;
      } // if
      
      if (e2 > x) err += ++x*2+1;
  } while (x <= 0);
}

//####################################################################################################################################################################################
//                                                                      ILI9341_FillScreen()
//
// Zeichnet das ganze Display ein
//
//                               Variablen
// @ color    : Farbe f�r das ganze Display
//
void ILI9341_FillScreen(uint16_t color)
{       
  ILI9341_SetX(0, LCD_WIDTH - 1);                                                // W�hle alle aus der X- und
  ILI9341_SetY(0, LCD_HEIGH - 1);                                                // Y-Koordinate aus.-
  ILI9341_SendComand(ILI9341_RAMWR);                                             // Schreibe die Info in der Memory
                                                                 
  P1OUT |= ILI9341_DC;                                                           // Daten werden nun manuel gesendet ...
  P1OUT &=~ ILI9341_CS;                                                          // Frame startet ...

  uint8_t high = color>>8;                                                       // Farbe in Low und High unterteilen ...
  uint8_t low = color&0xff;                                                      // ...
  for(long int i=0; i < ILI9341_PIXEL; i++)                                      // F�r ILI9341_PIXEL = 320 x 240 Pixels ausf�hren ...
  {     
    ILI9341_SPI_transmit(high);                                                  // Sende High- und ...
    ILI9341_SPI_transmit(low);                                                   // Sende Low-Byte ...
  } // for
  
  P1OUT |= ILI9341_CS;                                                           // Frame endet
}

//####################################################################################################################################################################################
//                                                                      ILI9341_FillRectangle()
//
// F�ll ein Rechteck auf das Display ein.
//
//                               Variablen
// @ x        : X-Position auf das Display
// @ y        : Y-Position auf das Display
// @ length   : L�nge des Rechtecks
// @ width    : Breite des Rechtecks
// @ color    : Farbe des Rechtecks
//
void ILI9341_FillRectangle(uint16_t x, uint16_t y, uint16_t length, uint16_t width, uint16_t color)
{
  unsigned long  XY=0;
  unsigned long i=0;
  uint16_t XL = x, XR = x+length, YU = y, YD = y+width;
  
  if(XL > XR)
  {
    XL = XL^XR;
    XR = XL^XR;
    XL = XL^XR;
  } // if
  
  if(YU > YD)
  {
    YU = YU^YD;
    YD = YU^YD;
    YU = YU^YD;
  } // if
  
  XY = (XR-XL+1);
  XY = XY*(YD-YU+1);

  ILI9341_SetX(XL,XR);
  ILI9341_SetY(YU, YD);
  ILI9341_SendComand(ILI9341_RAMWR);                                                
       
  P1OUT |= ILI9341_DC;
  P1OUT &=~ ILI9341_CS;

  uint8_t Hcolor = color>>8;
  uint8_t Lcolor = color&0xff;
  for(i=0; i < XY; i++)
  {
    ILI9341_SPI_transmit(Hcolor);
    ILI9341_SPI_transmit(Lcolor);
  }

  P1OUT |= ILI9341_CS;   
}

//####################################################################################################################################################################################
//                                                                      ILI9341_FillCircle()
//
// F�llt ein Kreis auf das Display ein.
//
//                               Variablen
// @ pox      : X-Position auf das Display
// @ poy      : Y-Position auf das Display
// @ r        : Radius des Kreises
// @ color    : Farbe des Kreises
//
void ILI9341_FillCircle(int poX, int poY, int r,uint16_t color)
{
  int x = -r, y = 0, err = 2-2*r, e2;
  do {

     ILI9341_DrawVLine(poX-x, poY-y, 2*y, color);
     ILI9341_DrawVLine(poX+x, poY-y, 2*y, color);

      e2 = err;
      if (e2 <= y) {
          err += ++y*2+1;
          if (-x == y && e2 <= x) e2 = 0;
      } // if
      
      if (e2 > x) err += ++x*2+1;
  } while (x <= 0);
}

//####################################################################################################################################################################################
//                                                                      ILI9341_GraphDemo()
//
// Demo-Funktion zeigt dem Anwender alle wichtigen grafischen Funktionen.
//
void ILI9341_GraphDemo(void)
{
  // 1. Some Colors
  ILI9341_FillScreen(ILI9341_BLACK);
  __delay_cycles(DELAY_10ms);
  ILI9341_FillScreen(ILI9341_RED);
  __delay_cycles(DELAY_10ms);
  ILI9341_FillScreen(ILI9341_GREEN);
  __delay_cycles(DELAY_10ms);
  ILI9341_FillScreen(ILI9341_YELLOW);
  __delay_cycles(DELAY_10ms);
  ILI9341_FillScreen(ILI9341_ORANGE);
  __delay_cycles(DELAY_10ms);
  ILI9341_FillScreen(ILI9341_BLUE);
  __delay_cycles(DELAY_10ms);
  ILI9341_FillScreen(ILI9341_GREY);
  
  // 2. Draw
  for (int i = 0; i < 1000; i++)
  {
    int x = rand() % LCD_WIDTH;
    int y = rand() % LCD_HEIGH;
    
    ILI9341_DrawPixel(x, y, ILI9341_RED);
    __delay_cycles(DELAY_1ms);
  } // for
  
  for (int i = 0; i < 1000; i++)
  {
    int x = rand() % LCD_WIDTH;
    int y = rand() % LCD_HEIGH;
    
    ILI9341_DrawPixel(x, y, ILI9341_BLUE);
    __delay_cycles(DELAY_1ms);
  } // for
  
    for (int i = 0; i < 1000; i++)
  {
    int x = rand() % LCD_WIDTH;
    int y = rand() % LCD_HEIGH;
    
    ILI9341_DrawPixel(x, y, ILI9341_YELLOW);
    __delay_cycles(DELAY_1ms);
  } // for
  
  // 3. Rectangel
  
  ILI9341_FillRectangle(0, 60, 60, 60,ILI9341_YELLOW);
  __delay_cycles(DELAY_100ms);
  ILI9341_FillRectangle(90, 60, 60, 60,ILI9341_BLUE);
  __delay_cycles(DELAY_100ms);
  ILI9341_FillRectangle(180, 60, 60, 60,ILI9341_RED);
  __delay_cycles(DELAY_100ms);
  
  ILI9341_FillCircle(30, 180, 30,ILI9341_YELLOW);
  __delay_cycles(DELAY_100ms);
  ILI9341_FillCircle(120, 180, 30,ILI9341_BLUE);
  __delay_cycles(DELAY_100ms);
  ILI9341_FillCircle(210, 180, 30,ILI9341_RED);
  __delay_cycles(DELAY_100ms);
  
  ILI9341_FillScreen(ILI9341_BLACK);
  ILI9341_DrawString("Follow me",85, 120, 1, ILI9341_BLUE);
  __delay_cycles(DELAY_1s);
  ILI9341_FillScreen(ILI9341_BLACK);
  ILI9341_DrawString("on",117, 120, 1, ILI9341_BLUE);
   __delay_cycles(DELAY_1s);
     
  for(int i = 0; i < 10; i++)
  {
    ILI9341_FillScreen(ILI9341_BLACK);
    __delay_cycles(DELAY_10ms);
    ILI9341_DrawString("www.electrodummies.net",57, 120, 1, ILI9341_BLUE);
    __delay_cycles(DELAY_100ms);
  } // fo


}