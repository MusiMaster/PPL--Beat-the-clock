#include <msp430.h>
#include "ili9341.h"





void main(void)
{
  // --- 1. MSP430-Stop Watchdog -----------------------------------------------
  
  WDTCTL = WDTPW + WDTHOLD;                                                      // Stop Watchdog-Timer 

  // --- 2. Setze MSP430-Clock -------------------------------------------------
  
  if (CALBC1_16MHZ==0xFF) while(1);  					         // If calibration constant erased. Do not load, trap CPU!!	  
  DCOCTL = 0;                                                                    // Nehme niedrigste Frequenz, DCOx and MODx settings
  BCSCTL1 = CALBC1_16MHZ;                                                         // Range
  DCOCTL = CALBC1_16MHZ;                                                          // DCO-Step + Modulation 
    
  ILI9341_SPI_init();				// init. USCI (SPI)
  ILI9341_Init(ILI9341_RED);			// init. Display
  
  _EINT();							// enable interrupts

  while(1)
  {  

     __delay_cycles(DELAY_10ms);
     ILI9341_GraphDemo();
  }
}



