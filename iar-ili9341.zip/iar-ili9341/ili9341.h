//###################################################################################################################################################################################
//
// Headerdatei der Bibliothek "ili9341.h"
//
// Ersteller : K. Evangelos 
// Datum     : Juni 2016
// Umgebung  : IAR Embedded Workbench IDE 6.10
//
// Erl�utert : * Inhalt: - Allgemein Defines (Timing, true, false, ...)
//                       - ILI9341 BEFEHLSSATZ
//                       - ILI9341 FARBEN
//                       - Prototypen
//
//             * Diese Library erm�glicht es den ILI9341 Kontroller �ber SPI mit 8 MHz anzusteuern. Als Pinout schlage ich vor:
//
//                 MSP430G2553        |  ILI9341-TFT-Display 240x320
//              ----------------------| -----------------------------   
//              3,3V                  |    Pin 1 - Vcc
//              GND                   |    Pin 2 - GND
//              Chip Select - P1.4    |    Pin 3 - CS 
//              Reset       - P1.0    |    Pin 4 - RST
//              Data/Cmd    - P1.6    |    Pin 5 - DC
//              MOSI        - P1.7    |    Pin 6 - SDI 
//              Clock       - P1.5    |    Pin 7 - SCK 
//              Vcc                   |    Pin 8 - LED     
//              NC                    |    Pin 9 - SDO
//              
//             * Um die Software f�r einen anderen MCU zu nutzen, muss du folgende 4 Punkte �ndern:
//
//               1. Die GPIOs �ndern. Dazu folgende 5 Defines manipulieren
//                  ILI9341_CS, ILI9341_MOSI, ILI9341_SCK, ILI9341_DC, ILI9341_RST
//
//               2. Deine eigene SPI Transmit Funktion schreiben. Diese sollte folgendes Schema haben
//                  unsigned char ILI9341_SPI_transmit (unsigned char data)
//                  {
//                    // Sende Daten �ber TX-Puffer
//                    // Warte bis Daten �bermittelt
//                    // Gebe RX-Puffer zur�ck (falls empfangen erw�nscht ist)
//                  }
//
//               3. Deine eigene SPI Funktion Initialisieren. Diese sollte folgendes Schema haben
//                  void ILI9341_SPI_init (void)
//                  {
//                    // SPI f�r Incative Low, MSB first, 8-Bit, MCU ist Master einstellen
//                    // SPI Modi 0,0 (Clock = Inactive Low, CPHA = Low)
//                    // SPI Frequenz maximal 10MHz
//                    // SPI aktivieren
//                    // SPI Dummy senden (8Bit)
//                  }

//                4. Die Library f�r uint8_t, uint16_t, uint32_t einf�gen. Dazu in der Header
//                   #include <stdint.h> 
//   
//
// Quellen   : - https://github.com/gmtii/ili9341-arduino/blob/master/TFTv2.h    // In Anlehnung dazu. Von C++ in C �bersetzt und daraufhin f�r MSP430 optimiert
//             - ILI9341.pdf                                                     // Datenblatt vom Hersteller
// 
//####################################################################################################################################################################################

#ifndef ILI9341_H
#define ILI9341_H

#include <msp430.h>
#include <stdint.h>
#include <stdlib.h>

//########################## ALLGEMEIN DEFINES #######################################################################################################################################

#define F_CPU       16000000                                                     // Frequenz mit der die CPU arbeitet

#define DELAY_1s    F_CPU                                                        // F�r __delay_cycles() ...
#define DELAY_100ms (F_CPU / 10)                                                 // ...
#define DELAY_10ms  (F_CPU / 100)                                                // ...
#define DELAY_1ms   (F_CPU / 1000)                                               // ...
#define DELAY_100us (F_CPU / 10000)                                              // ...
#define DELAY_10us  (F_CPU / 100000)                                             // ...
#define DELAY_1us   (F_CPU / 1000000)                                            // .-

#define BOOL char
#define TRUE 0
#define FALSE 1

#define ILI9341_CS	BIT4		                                         // Chip Select - P1.4
#define ILI9341_MOSI	BIT7		                                         // MOSI        - P1.7
#define ILI9341_SCK	BIT5		                                         // Clock       - P1.5
#define ILI9341_DC	BIT6		                                         // Data/Cmd    - P1.6
#define ILI9341_RST 	BIT0		                                         // Reset       - P1.0


//############################# ILI9341 BEFEHLSSATZ ###################################################################################################################################

#define ILI9341_TFT_WIDTH  240                                                   // Breite
#define ILI9341_TFT_HEIGHT 320                                                   // L�nge

#define ILI9341_NOP        0x00                                                  // Keine Operation
#define ILI9341_SWRESET    0x01                                                  // Software-Reset
#define ILI9341_RDDID      0x04
#define ILI9341_RDDST      0x09

#define ILI9341_SLPIN      0x10                                                  // Gehe im Sleep-Modus
#define ILI9341_SLPOUT     0x11                                                  // Wache aus dem Sleep-Modus auf
#define ILI9341_PTLON      0x12
#define ILI9341_NORON      0x13

#define ILI9341_RDMODE     0x0A
#define ILI9341_RDMADCTL   0x0B
#define ILI9341_RDPIXFMT   0x0C
#define ILI9341_RDIMGFMT   0x0A
#define ILI9341_RDSELFDIAG 0x0F

#define ILI9341_INVOFF     0x20                                                  // Invetierte Farben aus
#define ILI9341_INVON      0x21                                                  // Invetierte Farben ein
#define ILI9341_GAMMASET   0x26
#define ILI9341_DISPOFF    0x28                                                  // Display aus
#define ILI9341_DISPON     0x29                                                  // Display an

#define ILI9341_CASET      0x2A                                                  // Column Address Set, die X-Koordinate. Datenblatt - Seite 110, 111
#define ILI9341_PASET      0x2B                                                  // Page Address Set, die Y-Koordinate. Datenblatt - Seite 112, 113
#define ILI9341_RAMWR      0x2C                                                  // Write Memory, schreibt die Info im Speicher. Datenblatt - Seite 112, 113
#define ILI9341_RAMRD      0x2E                                                  // Read memory

#define ILI9341_PTLAR      0x30
#define ILI9341_MADCTL     0x36                                                  // Memory Acces Control - Seiten 127, 128
#define ILI9341_PIXFMT     0x3A

#define ILI9341_FRMCTR1    0xB1
#define ILI9341_FRMCTR2    0xB2
#define ILI9341_FRMCTR3    0xB3
#define ILI9341_INVCTR     0xB4
#define ILI9341_DFUNCTR    0xB6

#define ILI9341_PWCTR1     0xC0
#define ILI9341_PWCTR2     0xC1
#define ILI9341_PWCTR3     0xC2
#define ILI9341_PWCTR4     0xC3
#define ILI9341_PWCTR5     0xC4
#define ILI9341_VMCTR1     0xC5
#define ILI9341_VMCTR2     0xC7

#define ILI9341_RDID1      0xDA
#define ILI9341_RDID2      0xDB
#define ILI9341_RDID3      0xDC
#define ILI9341_RDID4      0xDD

#define ILI9341_GMCTRP1    0xE0
#define ILI9341_GMCTRN1    0xE1

#define MEM_Y   7                                                                // F�r die Orientation ...
#define MEM_X   6                                                                // ...
#define MEM_V   5                                                                // ...
#define MEM_L   4                                                                // ...
#define MEM_BGR 3                                                                // ...
#define MEM_H   2                                                                // .-

//####################################################################################################################################################################################

#define MIN_X	0                                                                // Extremwerte f�r Display abfangen ...
#define MIN_Y	0                                                                // ...
#define MAX_X	239                                                              // ...
#define MAX_Y	319                                                              // .-

#define LCD_ORIENTATION 0                                                        // Nur 1 von den 4 ausw�hlen. Portrait A ...
//#define LCD_ORIENTATION 90                                                     //                            Landscape A ...
//#define LCD_ORIENTATION 180                                                    //                            Portrait B ...
//#define LCD_ORIENTATION 270                                                    //                            Landscape B.-

#if (LCD_ORIENTATION == 90) || (LCD_ORIENTATION == 270)                          // Je nach Orientation nehme geignetet with und high ...
  #define LCD_WIDTH  320                                                         // ...
  #define LCD_HEIGH  240                                                         // ...
#else
  #define LCD_WIDTH  240                                                         // ...
  #define LCD_HEIGH  320                                                         // .-
#endif

#define ILI9341_PIXEL		76800                                            // 240 x 320 = 76800

//########################## ILI9341 FARBEN ##########################################################################################################################################

#define ILI9341_WHITE			0xFFFF                                   // VGA Farben (in RGB565, 16bit) ...
#define ILI9341_SILVER		        0xC618                                   // ...
#define ILI9341_BLACK			0x0000                                   // ...
#define ILI9341_GREY			0x8410                                   // ...
#define ILI9341_RED			0xF800                                   // ...
#define ILI9341_MAROON		        0x8000                                   // ...
#define ILI9341_TRANSP		        0xF81F                                   // ...
#define ILI9341_PURPLE		        0x8010                                   // ...
#define ILI9341_LIME			0x07E0                                   // ...
#define ILI9341_GREEN			0x0400                                   // ...
#define ILI9341_GREEN2		        0xB723                                   // ...
#define ILI9341_YELLOW		        0xFFE0                                   // ...
#define ILI9341_OLIVE		       	0x8400                                   // ...
#define ILI9341_BLUE			0x001F                                   // ...
#define ILI9341_NAVY			0x0010                                   // ...
#define ILI9341_COLOR_CYAN		0x07FF                                   // ...
#define ILI9341_AQUA			0x07FF                                   // ...
#define ILI9341_TEAL			0x0410                                   // ...
#define ILI9341_ORANGE		        0xFBE4                                   // ...
#define ILI9341_BROWN			0xBBCA                                   // ...
#define ILI9341_DARK_BLUE		0x0002                                   // .-

//################################### PROTOTYPEN ######################################################################################################################################

void ILI9341_SPI_init(void);                                                     // Initialisiert SPI-UCB0
unsigned char ILI9341_SPI_transmit(unsigned char data);                          // Senden und Empfangen �ber SPI-UCB0                                      
 
void ILI9341_SendComand(uint8_t cmd);                                            // Sende dem ILI9341 einen Befehl  �ber SPI-UCB0
void ILI9341_SendData8(uint8_t data);                                            // Sende dem ILI9341 einen 8-Bit-Datensatz �ber SPI-UCB0
void ILI9341_SendData16(uint16_t data);                                          // Sende dem ILI9341 einen 16-Bit-Datensatz �ber SPI-UCB0
void ILI9341_SendPackage(uint16_t *data,uint8_t howmany);                        // Sende dem ILI9341 eine Packet aud Daten (Array)
void ILI9341_Init(uint16_t color);                                               // Initialisiert das ILI9341-Display
void ILI9341_Orientation (int deg);                                              // Stellt die Ausrichtung vom Display 
void ILI9341_DisplayINV(char inv);                                               // Regelt das Inventieren der Farben des Displays
void ILI9341_DisplayONorOFF(char ONorOFF);                                       // Regelt das ein- oder auschalten des Displays

void ILI9341_SetX(uint16_t StartCol,uint16_t EndCol);                            // Stellt nur die X-Koordinate
void ILI9341_SetY(uint16_t StartPage,uint16_t EndPage);                          // Stellt nur die Y-Koordinate
void ILI9341_SetXY(uint16_t x, uint16_t y);                                      // Stellt die X und Y-Koordinaten f�r das Pixel ein und schreibte es in der Memory (ILI9341_RAMWR)
void ILI9341_SetPixel(uint16_t poX, uint16_t poY,uint16_t color);

void ILI9341_DrawPixel(int16_t x, int16_t y, uint16_t color);                    // Zeichnet dem Display einzelne Pixels ein
void ILI9341_DrawPixelXY(int16_t, int16_t, uint8_t, uint8_t, uint16_t);          // Zeichnet dem Display mehrere Pixels ein
void ILI9341_DrawChar(uint8_t,uint16_t,uint16_t,uint16_t,uint16_t);              // Zeichnet ein einzelnes Zeichen auf ds Display.
void ILI9341_DrawString(char*,uint16_t, uint16_t, uint16_t,uint16_t);            // Zeichnet ein string (Zeichen-Array) auf ds Display.
void ILI9341_DrawVLine(uint16_t x, uint16_t y,uint16_t length,uint16_t color);   // Zeichnet einne vertikale Linie ein.
void ILI9341_DrawHLine(uint16_t x, uint16_t y,uint16_t length,uint16_t color);   // Zeichnet einne horizontale Linie ein.
void ILI9341_DrawLine(uint16_t,uint16_t,uint16_t,uint16_t y1,uint16_t);          // Zeichnet einne Linie ein.
void ILI9341_DrawRectangle(uint16_t, uint16_t, uint16_t,uint16_t,uint16_t);      // Zeichnet ein Rechteck auf das Display ein.
void ILI9341_DrawCircle(int poX, int poY, int r,uint16_t color);                 // Zeichnet ein Kreis auf das Display ein.

void ILI9341_FillScreen(uint16_t color);                                         // Zeichnet das ganze Display ein
void ILI9341_FillRectangle(uint16_t, uint16_t, uint16_t, uint16_t, uint16_t);    // F�ll ein Rechteck auf das Display ein.
void ILI9341_FillCircle(int poX, int poY, int r,uint16_t color);                 // F�llt ein Kreis auf das Display ein.

void ILI9341_GraphDemo(void);                                                    // Demo-Funktion zeigt dem Anwender alle wichtigen grafischen Funktionen.

#endif